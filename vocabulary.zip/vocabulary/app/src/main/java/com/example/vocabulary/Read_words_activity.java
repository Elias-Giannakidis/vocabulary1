package com.example.vocabulary;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Read_words_activity extends AppCompatActivity {

    TextView greekText, englishText, commendText, scoreText, viewsText;
    Button nextButton, previousButton, deleteButton, testButton;
    int position = -1;

    Word word;
    ArrayList<Word> wordArrayList = new ArrayList<Word>();

    Cursor cursor;
    MyDatabaseHelper myDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_words);
        initialize();
    }

    private void initialize(){
        myDatabaseHelper = new MyDatabaseHelper(Read_words_activity.this);
        readAll();
        greekText = findViewById(R.id.greek_read_text);
        englishText = findViewById(R.id.english_read_text);
        commendText = findViewById(R.id.commend_read_text);
        scoreText = findViewById(R.id.score_read_text);
        viewsText = findViewById(R.id.views_read_text);
        nextButton = findViewById(R.id.next_read_button);
        previousButton = findViewById(R.id.previoius_read_button);
        deleteButton = findViewById(R.id.delete_read_button);
        testButton = findViewById(R.id.testButton);
        setListeners();
        readNext();
    }

    private void setListeners(){
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readNext();
            }
        });

        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(position > 0){
                    readPrevious();
                }
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delete();
            }
        });

        testButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addViews();
            }
        });

    }

    private void readNext(){
        position++;
        if (wordArrayList.size() > position ) {
            word = wordArrayList.get(position);
            englishText.setText(word.getEnglish());
            greekText.setText(word.getGreek());
            commendText.setText(word.getSentence());
            scoreText.setText(String.valueOf(word.getScore()));
            viewsText.setText(String.valueOf(word.getViews()));
        }else{
            position--;
        }
    }

    private void readPrevious(){
        if (position > 0) {
            position--;
        }
        word = wordArrayList.get(position);
        englishText.setText(word.getEnglish());
        greekText.setText(word.getGreek());
        commendText.setText(word.getSentence());
        scoreText.setText(String.valueOf(word.getScore()));
        viewsText.setText(String.valueOf(word.getViews()));
    }

    private void readAll(){
        Boolean done = false;
        cursor = myDatabaseHelper.readAll();
        while(!done) {
            if (cursor.move(1)) {
                wordArrayList.add(new Word(cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getInt(4), cursor.getInt(5)));
            }else{
                done = true;
            }
        }
    }

    private void delete(){
        if(!wordArrayList.isEmpty()) {
            cursor.moveToPosition(position);
            myDatabaseHelper.delete(String.valueOf(cursor.getInt(0)));
            wordArrayList.clear();
            readAll();
            if (wordArrayList.isEmpty()) {
                englishText.setText("Empty");
                greekText.setText("Empty");
                commendText.setText("Empty");
                scoreText.setText("Empty");
                viewsText.setText("Empty");
            } else {
                readPrevious();
            }
        }
    }

    private void addViews(){
        if(wordArrayList.size() > position) {
            cursor.moveToPosition(position);
            myDatabaseHelper.update(String.valueOf(cursor.getInt(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getInt(4) + 1, cursor.getInt(5));
            wordArrayList.clear();
            readAll();
            position++;
            readPrevious();
        }
    }

}