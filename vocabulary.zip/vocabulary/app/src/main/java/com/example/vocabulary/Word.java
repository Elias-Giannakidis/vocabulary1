package com.example.vocabulary;

public class Word {
    private String english, greek, sentence;
    private int score, views;

    public  Word (String english, String greek, String sentence, int views, int score){
        this.english = english;
        this.greek = greek;
        if(sentence.equals("")){
            this.sentence = "No sentence";
        }else{
            this.sentence = sentence;
        }

        this.score = score;
        this.views = views;
    }

    public String getEnglish(){
        return this.english;
    }

    public String getGreek(){
        return this.greek;
    }

    public String getSentence(){
        return sentence;
    }

    public int getScore(){
        return score;
    }

    public int getViews(){
        return views;
    }

}
