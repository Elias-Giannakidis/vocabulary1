package com.example.vocabulary;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class add_word extends AppCompatActivity {

    Button addButton;
    TextView english, greek, sentence;
    MyDatabaseHelper myDatabaseHelper;

    private void setListeners(){
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myDatabaseHelper.add(new Word(english.getText().toString(), greek.getText().toString(), sentence.getText().toString(),0, 0));
                english.setText("");
                greek.setText("");
                sentence.setText("");
            }
        });
    }

    private void initialize(){
        addButton = findViewById(R.id.add_button);
        english = findViewById(R.id.english);
        greek = findViewById(R.id.greek);
        sentence = findViewById(R.id.category);
        myDatabaseHelper = new MyDatabaseHelper(add_word.this);
        setListeners();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_word);
        initialize();
    }

}