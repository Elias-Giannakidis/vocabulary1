package com.example.vocabulary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    MyDatabaseHelper myDatabaseHelper;
    Button addWords, readWords;
    Intent intent;


    private void openAddWordActivity(){
        intent = new Intent(this, add_word.class);
        startActivity(intent);
    }

    private void openReadActivity(){
        intent = new Intent(this, Read_words_activity.class);
        startActivity(intent);
    }

    private void addListeners(){

       addWords.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               openAddWordActivity();
           }
       });

       readWords.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View view){
                openReadActivity();
           }
       });

    }

    private void initialize(){
        myDatabaseHelper = new MyDatabaseHelper(MainActivity.this);
        addWords = findViewById(R.id.add_words);
        readWords = findViewById(R.id.read_words);
        addListeners();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }

}